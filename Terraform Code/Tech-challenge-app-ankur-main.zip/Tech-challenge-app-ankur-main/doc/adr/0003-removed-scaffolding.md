# 3. removed scaffolding

Date: 2018-08-09

## Status

Accepted

## Context

Should we provide scaffolding for the test takers, or should we expect them to be able to set that up themselves?

## Decision

We decided to remove the scaffolding and rather suggest that the test taker uses the default VPC to deploy their application.

## Consequences

Some people will spend exta time to deploy the network infrastructure, which might make the test seem a lot bigger than it is.
